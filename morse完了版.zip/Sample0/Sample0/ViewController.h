//
//  ViewController.h
//  Sample0
//
//  Created by e115766 on 2013/12/01.
//  Copyright (c) 2013年 e115766. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIView *background;
@property (weak, nonatomic) IBOutlet UIStepper *TempoStepper;
@property (weak, nonatomic) IBOutlet UILabel *TempoText;

- (IBAction)button0:(id)sender;
- (IBAction)TempoButton:(id)sender;
- (IBAction)button1:(id)sender;
- (IBAction)button2:(id)sender;

@end

@interface Light : NSObject
- (id)initLight:(UIView *)bg;
- (void)switched;
@end

@interface switchLight : NSObject

- (id)initSwitch:(Light *)light;
- (void)light_on_off;

@end



/* 以下、点滅も勉強中です。次回のスプリントでしっかりと実装します。
 * 以下は触る必要なし。
 */
@interface BlinkingLight : switchLight

- (void)startBlinking:(int)TempoTime;
- (void)stopBlinking;
- (void)blinking:(NSTimer *)timer;

@end

@interface MorseLight : BlinkingLight
- (void)stopMorse;
- (void)sos;
- (void)straightKey;
- (void)singleKey;
@end

@interface Key : NSOperation
- (id)initKey:(id)target selector:(SEL)method;
@end
