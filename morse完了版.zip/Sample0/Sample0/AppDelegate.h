//
//  AppDelegate.h
//  Sample0
//
//  Created by e115766 on 2013/12/01.
//  Copyright (c) 2013年 e115766. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
