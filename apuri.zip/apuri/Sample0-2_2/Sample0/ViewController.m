//
//  ViewController.m
//  Sample0
//
//  Created by e115766 on 2013/12/01.
//  Copyright (c) 2013年 e115766. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

/* 実機が無いため、ライトの代わりに背景色を使用しています。
 */

@implementation ViewController
{
    // ライトデバイスのインスタンス変数（現在は、ライトの代わりに背景色に関するデバイス）
    id _light;
    
    // 点灯および消灯を行うクラス
    id _lightSwitch;
    
    //点滅
    id _blinklight;
    BOOL _blink_f;
    
    //モールス
    id _morselight;
    BOOL _morse_f;
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _light = [[Light alloc] initLight:self.background];
    _lightSwitch = [[switchLight alloc] initSwitch:_light];
    _blinklight = [[BlinkingLight alloc] initSwitch:_light];
    _morselight = [[MorseLight alloc] initSwitch:_light];
    
    self.TempoStepper.value = 100;
    self.TempoStepper.minimumValue = 1;
    self.TempoStepper.maximumValue = 200;
    self.TempoStepper.stepValue = 1;
    
    _blink_f = false;
    _morse_f = false;
    
    self.TempoText.text = [NSString stringWithFormat:@"%d", (int)self.TempoStepper.value];
    
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//ボタンが押されるとこのメソッドが呼ばれます。
- (IBAction)onoffButton:(id)sender {
    [_lightSwitch light_on_off];
    
    UIImage *img;
    if([_light get_On_Off])
        img = [UIImage imageNamed:@"on1.png"];
    else
        img = [UIImage imageNamed:@"off1.png"];
    [_onOffButton setImage:img forState:UIControlStateNormal];
}

- (IBAction)metroButton:(id)sender {
    if (_blink_f == false){
        [_blinklight startBlinking:self.TempoStepper.value];
        _blink_f = true;
    }
    else {
        [_blinklight stopBlinking];
        _blink_f = false;
    }
    
    UIImage *img;
    if (_blink_f == true){
        img = [UIImage imageNamed:@"metoro_on.png"];
        [_bl setImage:img forState:UIControlStateNormal];
    }
    else {
        img = [UIImage imageNamed:@"metoro_off.png"];
        [_bl setImage:img forState:UIControlStateNormal];
    }
}

- (IBAction)sosButton:(id)sender {
    if (_morse_f == false){
        [_morselight sos:_ms];
        _morse_f = true;
    }
    else{ //ここが
        [_morselight stopMorse];
        _morse_f = false;
    }
}

- (IBAction)hungryButton:(id)sender {
    if (_morse_f == false){
        [_morselight hungry:_mh];
        _morse_f = true;
    }
    else{ //ここが
        [_morselight stopMorse];
        _morse_f = false;
    }
}

- (IBAction)datemeButton:(id)sender {
    if (_morse_f == false){
        [_morselight dateme:_md];
        _morse_f = true;
    }
    else{ //ここが
        [_morselight stopMorse];
        _morse_f = false;
    }
}

- (IBAction)helloButton:(id)sender {
    if (_morse_f == false){
        [_morselight hello:_mhe];
        _morse_f = true;
    }
    else{ //ここが
        [_morselight stopMorse];
        _morse_f = false;
    }
}

- (IBAction)TempoButton:(id)sender {
    self.TempoText.text = [NSString stringWithFormat:@"%d", (int)self.TempoStepper.value];
}


@end

/* Lightクラス
 * 便宜上作成しました。
 * 今回のコードでは、背景色を変更するメソッドが入っていますが、本来は実際のライトを扱うクラスです。
 */
@implementation Light
{
    int _on_off;
    UIView *_bg;
}

/* Lightクラスイニシャライザ
 * 戻り値：id　引数：(UIView *) bg
 * 背景色を扱う、UIViewインスタンスを引数としてとり、インスタンス変数に代入します。
 *******他の言語でいうところのコンストラクタにあたります。init()関数をオーバーライドしてつくります。*******
 */
- (id)initLight:(UIView *)bg{
    self = [self init];
    _bg = bg;
    
    return self;
}

/* 関数名:switched()
 * 戻り値：なし　引数：なし
 * この関数を呼び出すことでライトの点灯消灯ができます。
 * 消灯時は点灯を、点灯時は消灯を行います。（背景色が白黒かわります。）
 */
- (void)switched{
    // UIColor は色を扱うためのクラスです。
    UIColor *color;
    
    AVCaptureDevice *captureDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    // 現在のライトの状態により、点灯もしくは消灯を行います。
    if (_on_off == 0){
        color = [UIColor whiteColor];
        _on_off = 1;
        
        [captureDevice lockForConfiguration:NULL];
        captureDevice.torchMode = AVCaptureTorchModeOn; // ライトをONにする(上と下のものを入れないとONにできない)
        [captureDevice unlockForConfiguration];
        
        NSLog(@"点灯");
    }
    else {
        color = [UIColor blueColor];
        _on_off = 0;
        
        [captureDevice lockForConfiguration:NULL];
        captureDevice.torchMode = AVCaptureTorchModeOff; // ライトをOFFにする
        [captureDevice unlockForConfiguration];
        
        NSLog(@"消灯");
    }
    
    _bg.backgroundColor = color;
}

- (int)get_On_Off{ //get_rite_status
    return _on_off;
}

@end

/* switchLightクラス
 * 点灯/消灯クラスにあたります。またONクラスにもあたります。（クラス図にフィードバック修正が必要と思われます）
 */
@implementation switchLight
{
    // Lightクラスを直接扱うための変数
    Light *_light;
}

/* switchLightクラスイニシャライザ
 * 戻り値：id　引数：(Light *) light
 * ライトのデバイス(今回の場合はLightクラス)を扱うための変数を引数とし、インスタンス変数に代入。
 */
- (id)initSwitch:(Light *)light{
    self = [super init];
    _light = light;
    return (self);
}

/* 関数名：lighting()
 * 戻り値：なし　引数：なし
 * ライトのスイッチを押します。
 */
- (void)light_on_off{
    [_light switched];
}
@end

/* 以下、点滅も勉強中です。次回のスプリントでしっかりと実装します。
 * 以下は触る必要なし。
 */

@implementation BlinkingLight
{
    NSTimer *_timer;
}

- (void)startBlinking:(int)tempoTime{
    if(tempoTime <= 0){
        tempoTime = 1;
    }
    
    //すでに設定されているタイマーを停止
    [_timer invalidate];
    
    //タイマーを起動
    _timer = [NSTimer scheduledTimerWithTimeInterval:(60.0/tempoTime)
                                              target:self
                                            selector:@selector(blinking:)
                                            userInfo:nil
                                             repeats:YES];
}

- (void)stopBlinking{
    //タイマーを停止
    [_timer invalidate];
}

- (void)blinking:(NSTimer *)timer{
    [self light_on_off];
}

@end

@implementation MorseLight
{
    NSTimer* _timer;
    int _n;
    Boolean flag;
    NSOperationQueue *queue;
    
    UIButton* _buttonImage;
    
    BOOL _imageFlag;
}

- (void)stopMorse{
    [queue cancelAllOperations];
}

- (void)sos:(UIButton *) buttonImage{
    _buttonImage = buttonImage;
    queue = [NSOperationQueue mainQueue];
    NSLog(@"hello");
    _imageFlag = true;
    
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(changeButtonImagesos)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(changeButtonImagesos)]];
}

- (void)hello:(UIButton *) buttonImage{
    _buttonImage = buttonImage;
    queue = [NSOperationQueue mainQueue];
    NSLog(@"hello");
    _imageFlag = true;
    
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(changeButtonImagehello)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(changeButtonImagehello)]];
}

- (void)dateme:(UIButton *) buttonImage{
    _buttonImage = buttonImage;
    queue = [NSOperationQueue mainQueue];
    NSLog(@"hello");
    _imageFlag = true;
    
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(changeButtonImagedateme)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(changeButtonImagedateme)]];
}

- (void)hungry:(UIButton *) buttonImage{
    _buttonImage = buttonImage;
    queue = [NSOperationQueue mainQueue];
    NSLog(@"hello");
    _imageFlag = true;
    
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(changeButtonImagehungry)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(singleKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(straightKey)]];    
    [queue addOperation:[[Key alloc] initKey:self selector:@selector(changeButtonImagehungry)]];
}

- (void)straightKey{
    [NSThread sleepForTimeInterval:0.3];
    [self performSelectorInBackground:@selector(light_on_off) withObject:nil];
    [NSThread sleepForTimeInterval:0.9];
    [self performSelectorInBackground:@selector(light_on_off) withObject:nil];
}

- (void)singleKey{
    [NSThread sleepForTimeInterval:0.3];
    [self performSelectorInBackground:@selector(light_on_off) withObject:nil];
    [NSThread sleepForTimeInterval:0.3];
    [self performSelectorInBackground:@selector(light_on_off) withObject:nil];
}

- (void)changeButtonImagesos{
    UIImage *img;
    if (_imageFlag == true){
        img = [UIImage imageNamed:@"sos3_2.png"];
        [_buttonImage setImage:img forState:UIControlStateNormal];
        _imageFlag = false;
    }
    else {
        img = [UIImage imageNamed:@"sos3_1.png"];
        [_buttonImage setImage:img forState:UIControlStateNormal];
    }
}


- (void)changeButtonImagehello{
    UIImage *img;
    if (_imageFlag == true){
        img = [UIImage imageNamed:@"hello3_2.png"];
        [_buttonImage setImage:img forState:UIControlStateNormal];
        _imageFlag = false;
    }
    else {
        img = [UIImage imageNamed:@"hello3_1.png"];
        [_buttonImage setImage:img forState:UIControlStateNormal];
    }
}

- (void)changeButtonImagedateme{
    UIImage *img;
    if (_imageFlag == true){
        img = [UIImage imageNamed:@"date3_2.png"];
        [_buttonImage setImage:img forState:UIControlStateNormal];
        _imageFlag = false;
    }
    else {
        img = [UIImage imageNamed:@"date3_1.png"];
        [_buttonImage setImage:img forState:UIControlStateNormal];
    }
}

- (void)changeButtonImagehungry{
    UIImage *img;
    if (_imageFlag == true){
        img = [UIImage imageNamed:@"hungry3_2.png"];
        [_buttonImage setImage:img forState:UIControlStateNormal];
        _imageFlag = false;
    }
    else {
        img = [UIImage imageNamed:@"hungry3_1.png"];
        [_buttonImage setImage:img forState:UIControlStateNormal];
    }
}

@end

@implementation Key
{
    id _target;
    SEL _method;
}

- (id)initKey:(id)target selector:(SEL)method{
    self = [super init];
    _target = target;
    _method = method;
    return (self);
}
- (void)main{
    #pragma clang diagnostic push
    #pragma clang diagnostic ignored "-Warc-performSelector-leaks"
    [_target performSelector:_method];
    #pragma clang diagnostic pop
}

@end
