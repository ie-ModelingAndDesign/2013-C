//
//  ViewController.h
//  Sample0
//
//  Created by e115766 on 2013/12/01.
//  Copyright (c) 2013年 e115766. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h> // AVFoundation.frameworkを使う

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIView *background;
@property (weak, nonatomic) IBOutlet UIStepper *TempoStepper;
@property (weak, nonatomic) IBOutlet UILabel *TempoText;

- (IBAction)onoffButton:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *onOffButton;

- (IBAction)TempoButton:(id)sender;
- (IBAction)metroButton:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *bl;

- (IBAction)sosButton:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *ms;

- (IBAction)hungryButton:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *mh;

- (IBAction)datemeButton:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *md;

- (IBAction)helloButton:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *mhe;

@end

@interface Light : NSObject
- (id)initLight:(UIView *)bg;
- (void)switched;
- (int)get_On_Off;
@end

@interface switchLight : NSObject

- (id)initSwitch:(Light *)light;
- (void)light_on_off;

@end



/* 以下、点滅も勉強中です。次回のスプリントでしっかりと実装します。
 * 以下は触る必要なし。
 */
@interface BlinkingLight : switchLight

- (void)startBlinking:(int)TempoTime;
- (void)stopBlinking;
- (void)blinking:(NSTimer *)timer;

@end

@interface MorseLight : BlinkingLight
- (void)stopMorse;
- (void)sos:(UIButton *) buttonImage;
- (void)hello:(UIButton *) buttonImage;
- (void)dateme:(UIButton *) buttonImage;
- (void)hungry:(UIButton *) buttonImage;
- (void)changeButtonImagehello;
- (void)changeButtonImagesos;
- (void)changeButtonImagedateme;
- (void)changeButtonImagehungry;


- (void)straightKey;
- (void)singleKey;
@end

@interface Key : NSOperation
- (id)initKey:(id)target selector:(SEL)method;
@end
