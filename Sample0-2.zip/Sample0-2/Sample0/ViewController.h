//
//  ViewController.h
//  Sample0
//
//  Created by e115766 on 2013/12/01.
//  Copyright (c) 2013年 e115766. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h> // AVFoundation.frameworkを使う

@interface ViewController : UIViewController // main ここから
@property (strong, nonatomic) IBOutlet UIView *background;

- (IBAction)button0:(id)sender;

@end // ここまでクラス

@interface Light : NSObject // デバイス　背景変わる Lightクラス（ライトクラス）
- (id)initLight:(UIView *)bg; // クラス作るのに必要　コンストラクタ
- (void)switched; // 実際の機能はここ
@end

@interface switchLight : NSObject //swichLightクラス（ONクラスor点滅消灯点灯クラス）

- (id)initSwitch:(Light *)light;
- (void)light_on_off;

@end



/* 以下、点滅も勉強中です。次回のスプリントでしっかりと実装します。
 * 以下は触る必要なし。
@interface BlinkingLight : switchLight // クラス名：継承するクラス（親クラス）

- (id)initLight:(UIView *)bg;
- (void)blinking:(NSTimer *)timer;

@end
*/