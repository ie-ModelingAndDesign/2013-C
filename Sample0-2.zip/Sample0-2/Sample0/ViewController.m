//
//  ViewController.m
//  Sample0
//
//  Created by e115766 on 2013/12/01.
//  Copyright (c) 2013年 e115766. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

/* 実機が無いため、ライトの代わりに背景色を使用しています。
 */

@implementation ViewController
{
    // ライトデバイスのインスタンス変数（現在は、ライトの代わりに背景色に関するデバイス）
    id _light;
    
    // 点灯および消灯を行うクラス
    id _lightSwitch;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _light = [[Light alloc] initLight:self.background]; // allocでLightを作る 引数で背景が渡される
    _lightSwitch = [[switchLight alloc] initSwitch:_light]; // selfは今いるクラス
    
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//ボタンが押されるとこのメソッドが呼ばれます。　ボタンクラス？
- (IBAction)button0:(id)sender {
    [_lightSwitch light_on_off];
}

@end

/* Lightクラス
 * 便宜上作成しました。
 * 今回のコードでは、背景色を変更するメソッドが入っていますが、本来は実際のライトを扱うクラスです。
 */
@implementation Light
{
    int _on_off; // 状態
    UIView *_bg; // 背景使うためのもの
}

/* Lightクラスイニシャライザ
 * 戻り値：id　引数：(UIView *) bg
 * 背景色を扱う、UIViewインスタンスを引数としてとり、インスタンス変数に代入します。
 *******他の言語でいうところのコンストラクタにあたります。init()関数をオーバーライドしてつくります。*******
 */
- (id)initLight:(UIView *)bg{ // コンストラクタ　initがイニシャライザを表す
    self = [self init];
    _bg = bg;
    
    return self;
}

/* 関数名:switched()
 * 戻り値：なし　引数：なし
 * この関数を呼び出すことでライトの点灯消灯ができます。
 * 消灯時は点灯を、点灯時は消灯を行います。（背景色が白黒かわります。） ここにライトいれる
 */
- (void)switched{ // light_on_offから値がくる
    // UIColor は色を扱うためのクラスです。
    UIColor *color;
    
    AVCaptureDevice *captureDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo]; // iPhoneのビデオカメラを使う
    
    // 現在のライトの状態により、点灯もしくは消灯を行います。
    if (_on_off == 0){
        color = [UIColor whiteColor];
        _on_off = 1;
        

        [captureDevice lockForConfiguration:NULL];
        captureDevice.torchMode = AVCaptureTorchModeOn; // ライトをONにする(上と下のものを入れないとONにできない)
        [captureDevice unlockForConfiguration];

        
        NSLog(@"点灯");
    }
    else {
        color = [UIColor blackColor]; // []で囲まれものが関数
        _on_off = 0;
        

        [captureDevice lockForConfiguration:NULL];
        captureDevice.torchMode = AVCaptureTorchModeOff; // ライトをOFFにする
        [captureDevice unlockForConfiguration];
        
        
        NSLog(@"消灯");
    }
    
    _bg.backgroundColor = color;
}
@end

/* switchLightクラス
 * 点灯/消灯クラスにあたります。またONクラスにもあたります。（クラス図にフィードバック修正が必要と思われます）
 */
@implementation switchLight // ここで実際につける消すの操作
{
    // Lightクラスを直接扱うための変数
    Light *_light; //上のLightクラス？の変数
}

/* switchLightクラスイニシャライザ
 * 戻り値：id　引数：(Light *) light
 * ライトのデバイス(今回の場合はLightクラス)を扱うための変数を引数とし、インスタンス変数に代入。
 */
- (id)initSwitch:(Light *)light{
    self = [super init];
    _light = light;
    return (self);
}

/* 関数名：lighting()
 * 戻り値：なし　引数：なし
 * ライトのスイッチを押します。
 */
- (void)light_on_off{ // 関数　ON・OFF
    [_light switched]; // デバイスのライトに送る信号（命令）
}
@end

/* 以下、点滅も勉強中です。次回のスプリントでしっかりと実装します。
 * 以下は触る必要なし。
@implementation BlinkingLight
{
    NSTimer *_timer;
}

 // NSTimerで点滅の間隔を設定
- (id)initLight:(UIView *)bg{
    self = [super initLight:bg];
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0f // 1秒に1回
                                              target:self
                                            selector:@selector(blinking:) // blinking実行
                                            userInfo:nil
                                             repeats:YES];
    
    return (self); //
}

- (void)blinking:(NSTimer *)timer{
    [self lighting]; // light_on_off
}

@end
 */
