//
//  main.m
//  HelloWorld
//
//  Created by e115766 on 2013/12/05.
//  Copyright (c) 2013年 e115766. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Profile.h"

/*
 * コマンドラインに結果がでるプログラムです。
 * 右上の再生マーク（三角）で実行、右下のコマンドラインに結果がでるはず。
 */

int main(int argc, const char * argv[])
{
    //@autoreleasepoolはガベージコレクションのようなものです。
    //（たぶん）iOSアプリの開発には関係ないので、気にしなくてよいです。
    @autoreleasepool {
        // id型の変数に、Profileのインスタンスを作ります。
        // [Profile alloc] でインスタンスを格納するためのメモリ領域を得ます。
        // 作ったインスタンスをinitProfileで初期化します。(p1, p2にそれぞれ任意の名前、身長、体重を入れてあげます。)
        id p1 = [[Profile alloc] initProfile:@"花子" Height:1.5 Weight:50];
        id p2 = [[Profile alloc] initProfile:@"太郎" Height:1.8 Weight:49];
        
        // p1, p2それぞれ同じメソッドを呼び出してあげます。
        // [インスタンス名 メソッド名]　をメッセージ式といい、Objective-Cではこれを使ってメソッドを呼び出します。
        // "p1"の"callName"を呼ぶ -> [p1 callName]
        // 同じ操作しかしていないはずですが、インスタンス変数の状態により出力結果が変わってきます。
        [p1 callName];
        [p1 getBMI];
        
        [p2 callName];
        [p2 getBMI];
    }
    return 0;
}

