//
//  Profile.m
//  HelloWorld
//
//  Created by e115766 on 2013/12/05.
//  Copyright (c) 2013年 e115766. All rights reserved.
//

#import "Profile.h"

/*
 * ソースファイル(.m)はクラス内のメソッド(関数)や変数を実装するファイルです。
 * (できれば、ヘッダファイルを先に読んでください。)
 */

// 名前、身長、体重のデータをもつProfileクラスを実装していきます。
// ヘッダファイルと違い親クラスについては書かない。
@implementation Profile
{
    /* ここからはクラスとインスタンスの関係に気をつけなければなりません。
     * 参考は以下。
     * http://www.atmarkit.co.jp/ait/articles/0803/12/news148.html
     */
    
    /*
     * 以下にインスタンス変数を宣言します。
     * インスタンス変数は、インスタンス内の全てのメソッド(関数)が使用できる変数です。
     * Objective-Cのインスタンス変数は慣習として"_"から始めるようです。(そうすることで、同じ役割のローカル変数との名前の重複を避けることができます。)
     *
     */
    
    // 名前
    NSString *_name;
    // 身長(メートル)
    float _height;
    // 体重(キログラム)
    int _weight;
}

// イニシャライザ
// 戻り値：id型(id型は全てのオブジェクト（インスタンス）を入れることができる型です。)
// 引数：名前, 身長, 体重
-(id)initProfile:(NSString *)name Height:(float)height Weight:(int)weight
{
    // 親クラスの構造を引き継ぎます。
    // selfはインスタンス自身です。superとは親クラスのオブジェクト、 initは親クラスのイニシャライザです。
    // [インスタンス名 メソッド名]　をメッセージ式といい、Objective-Cではこれを使ってメソッドを呼び出します。
    // つまり、self = [super init]は、"初期化した親クラスを自分自身とする(継承)"ということになります。
    self = [super init];
    
    // 引数をインスタンス変数に格納します。
    // (ここが親クラスとの差異となる)
    _name = name;
    _height = height;
    _weight = weight;
    
    return (self);
}

// インスタンスの名前を出力します。
-(void)callName
{
    // NSLogはコマンドラインへ出力するための関数。
    // Objective-Cでは文字列は @"text" で表します。
    NSLog(@"私の名前は%@です。\n", _name);
}

// インスタンスのBMIを計算し、出力します。
-(void)getBMI
{
    if (0 < _height * _height){
        NSLog(@"%@のBMI:%.1f\n", _name, _weight / (_height * _height));
    }
}

@end
